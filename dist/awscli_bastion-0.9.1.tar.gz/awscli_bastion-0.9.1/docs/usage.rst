=====
Usage
=====

To use awscli_bastion in a project::

    import awscli_bastion
