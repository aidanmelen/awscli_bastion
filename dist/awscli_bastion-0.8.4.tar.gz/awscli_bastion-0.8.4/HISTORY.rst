=======
History
=======

0.1.0 (2019-09-13)
------------------

* First release on PyPI.
