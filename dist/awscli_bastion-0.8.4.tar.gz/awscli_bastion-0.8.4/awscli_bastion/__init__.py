# -*- coding: utf-8 -*-

"""Top-level package for awscli_bastion."""

__author__ = """Aidan Melen"""
__email__ = 'aidan.l.melen@gmail.com'
__version__ = '0.8.3'
